if (typeof exports === 'object') {
	var assert = require('assert');
	var alasql = require('..');
}

describe('Test 72 - Explain', function() {
	//	it.skip('localStorage', function(done){
	//		done();
	//	});
});
