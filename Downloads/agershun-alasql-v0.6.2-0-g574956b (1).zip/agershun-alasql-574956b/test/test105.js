if (typeof exports === 'object') {
	var assert = require('assert');
	var alasql = require('..');
}

describe('Test 105 - Synchronization over browsers and Node.js', function() {});
