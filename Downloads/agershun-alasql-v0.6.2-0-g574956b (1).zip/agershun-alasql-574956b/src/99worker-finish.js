
/* WebWorker */
/** @type {number} */
alasql.lastid = 0;

/** @type {object} */
alasql.buffer = {};

alasql.worker();

return alasql;
}));
