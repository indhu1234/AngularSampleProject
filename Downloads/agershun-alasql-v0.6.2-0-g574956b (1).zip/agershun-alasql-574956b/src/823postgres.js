if (alasql.options.postgres) {
}
